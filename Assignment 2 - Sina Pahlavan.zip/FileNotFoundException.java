/**
 * File not Found Exception
 */
public class FileNotFoundException extends Exception{

    public FileNotFoundException(String message) {
        super(message);
    }
}