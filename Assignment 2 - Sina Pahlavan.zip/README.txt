Sina Pahlavan
501 034 271
Hello, 
All commands work properly.
There are a total of 9 exceptions. Specific explanations for each of them is provided in the files.
Each of these has its own classes as opposed to being in Flight.java so that they could be more organized and easier 
	to look at.

There are seven airplanes. Their capacities are 4,16,20,40,60,80 without any first class seats. There is also one airplane
with 100 economy and 12 first class seats. The seat layout is determined by these numbers. 
To assign an airplane to a flight, I go through an arraylist with all the flights and check to see if an airplane has
more than or equal the number of minimum seats as shown in the flight.txt file.

Everything is done as said in the instructions.

Also, I modified the flights text file. After the minimum seats string, I added a single number showing the duration of each flight. I got the number 
from the last assignment.